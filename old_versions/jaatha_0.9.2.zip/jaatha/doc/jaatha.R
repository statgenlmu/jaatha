### R code from vignette source 'jaatha.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: foo
###################################################
options(keep.source = TRUE, width = 60)
jinfo <- packageDescription("jaatha")


###################################################
### code chunk number 2: Loading Jaatha
###################################################
library(jaatha)


###################################################
### code chunk number 3: Creating a demographic model in R
###################################################
dm <- dm.createDemographicModel(sampleSizes=c(25,24),nLoci=100,
						seqLength=10^3)


###################################################
### code chunk number 4: Creating a demographic model in R
###################################################
dm <- dm.addSpeciationEvent(dm,.1,5)
dm <- dm.addSymmetricMigration(dm,.01,5)
dm <- dm.addMutation(dm,1,20)
dm <- dm.addRecombination(dm,fixed=5)


###################################################
### code chunk number 5: Checking the model
###################################################
dm


