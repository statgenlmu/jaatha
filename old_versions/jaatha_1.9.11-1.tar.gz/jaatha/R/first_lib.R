.First.lib <-function (lib, pkg)   {
       library.dynam("jaatha", pkg, lib)
       library.dynam("phyclust", pkg, lib)
}
