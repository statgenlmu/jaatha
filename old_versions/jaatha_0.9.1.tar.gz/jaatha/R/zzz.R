.First.lib <- function(lib, pkg)
{
  library.dynam("jaatha", pkg, lib)
}

.Last.lib <- function(libpath)
{
  library.dynam.unload("jaatha", libpath)
}
