### R code from vignette source 'jaatha.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: foo
###################################################
options(keep.source = TRUE, width = 60)
jinfo <- packageDescription("jaatha")
load('startpoints.save')


###################################################
### code chunk number 2: Loading Jaatha
###################################################
library(jaatha)


###################################################
### code chunk number 3: Creating a demographic model in R
###################################################
dm <- dm.createDemographicModel(sample.sizes=c(25,24), loci.num=100,
						seq.length=10^3)


###################################################
### code chunk number 4: Creating a demographic model in R
###################################################
dm <- dm.addSpeciationEvent(dm,.1,5)
dm <- dm.addSymmetricMigration(dm,.01,5)
dm <- dm.addMutation(dm,1,20)
dm <- dm.addRecombination(dm,fixed=20)


###################################################
### code chunk number 5: Checking the model
###################################################
dm


###################################################
### code chunk number 6: Summary Statistics
###################################################
pars 	<- c(1,1,10) 
simSumStats <- dm.simSumStats(dm,pars)
simSumStats


###################################################
### code chunk number 7: Initialize
###################################################
jaatha <- Jaatha.initialize(dm, simSumStats)


###################################################
### code chunk number 8: Initial Search
###################################################
Jaatha.printStartPoints(jaatha,startPoints)


###################################################
### code chunk number 9: <Pick points
###################################################
startPoints <- Jaatha.pickBestStartPoints(startPoints,2)


###################################################
### code chunk number 10: seed
###################################################
set.seed(50)


###################################################
### code chunk number 11: RefineSearch
###################################################
jaatha <- Jaatha.refineSearch(jaatha, startPoints,
                              nSim=50, nFinalSim=50,
			      epsilon=5, halfBlockSize=.05,
			      weight=.9, nMaxStep=200)


###################################################
### code chunk number 12: printLT
###################################################
Jaatha.printLikelihoods(jaatha)


